"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Phone,
  Send,
  Mic,
  MicOff,
  Settings,
  MoreVertical,
  Clock,
  Star,
  CheckCircle,
  AlertCircle,
  Loader2,
} from "lucide-react"
import Link from "next/link"

interface Message {
  id: string
  type: "user" | "bot" | "system"
  content: string
  timestamp: Date
  isTyping?: boolean
  deals?: Array<{
    seller: string
    price: number
    originalPrice?: number
    delivery: string
    rating: number
    negotiated: boolean
  }>
}

const initialMessages: Message[] = [
  {
    id: "1",
    type: "system",
    content: "DealFinder AI is now online and ready to help you find the best deals!",
    timestamp: new Date(Date.now() - 60000),
  },
  {
    id: "2",
    type: "bot",
    content:
      "Hi! I'm your AI deal-finding assistant. I can help you find the best prices on limited-edition sneakers, concert tickets, and exclusive drops by calling multiple resellers. What are you looking for today?",
    timestamp: new Date(Date.now() - 30000),
  },
]

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [inputValue, setInputValue] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [isSearching, setIsSearching] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const simulateBotResponse = (userMessage: string) => {
    setIsTyping(true)

    setTimeout(() => {
      setIsTyping(false)

      let botResponse = ""
      const deals = undefined

      if (userMessage.toLowerCase().includes("jordan") || userMessage.toLowerCase().includes("sneaker")) {
        botResponse =
          "Great! I'll search for Jordan sneakers across multiple resellers. Let me call them now and negotiate the best prices for you..."
        setIsSearching(true)

        setTimeout(() => {
          setIsSearching(false)
          const searchResults: Message = {
            id: Date.now().toString() + "_results",
            type: "bot",
            content: "Perfect! I've contacted 5 resellers and negotiated prices. Here are the top 3 deals I found:",
            timestamp: new Date(),
            deals: [
              {
                seller: "SneakerHub Pro",
                price: 450,
                originalPrice: 500,
                delivery: "2-3 days",
                rating: 4.8,
                negotiated: true,
              },
              {
                seller: "Kicks Central",
                price: 475,
                delivery: "1-2 days",
                rating: 4.6,
                negotiated: false,
              },
              {
                seller: "Urban Footwear",
                price: 520,
                originalPrice: 550,
                delivery: "3-5 days",
                rating: 4.9,
                negotiated: true,
              },
            ],
          }

          setMessages((prev) => [...prev, searchResults])

          setTimeout(() => {
            const followUp: Message = {
              id: Date.now().toString() + "_followup",
              type: "bot",
              content:
                "Would you like me to send these deals to your email or would you prefer to see more options? I can also continue negotiating for better prices!",
              timestamp: new Date(),
            }
            setMessages((prev) => [...prev, followUp])
          }, 1000)
        }, 3000)
      } else if (userMessage.toLowerCase().includes("concert") || userMessage.toLowerCase().includes("ticket")) {
        botResponse =
          "I'll help you find concert tickets! Which artist or event are you looking for? I can search across multiple ticket resellers and negotiate prices."
      } else if (userMessage.toLowerCase().includes("email")) {
        botResponse =
          "I'll send a detailed comparison report to your email right away! The report will include all the deals, seller ratings, delivery times, and my negotiation notes. You should receive it within the next few minutes."
      } else if (userMessage.toLowerCase().includes("price") || userMessage.toLowerCase().includes("cheaper")) {
        botResponse =
          "Let me contact the sellers again and see if I can negotiate better prices. I'll use my advanced negotiation algorithms to get you the best possible deals!"
      } else {
        botResponse =
          "I understand you're looking for deals! I can help you find the best prices on:\n\n• Limited-edition sneakers\n• Concert tickets\n• Sports event tickets\n• Fashion drops\n• Exclusive releases\n\nJust tell me what specific item you're interested in, and I'll start calling resellers immediately!"
      }

      const newMessage: Message = {
        id: Date.now().toString(),
        type: "bot",
        content: botResponse,
        timestamp: new Date(),
        deals,
      }

      setMessages((prev) => [...prev, newMessage])
    }, 1500)
  }

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    simulateBotResponse(inputValue)
    setInputValue("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    if (!isRecording) {
      // Simulate voice input
      setTimeout(() => {
        setIsRecording(false)
        setInputValue("I'm looking for Jordan 4 Black Cat in size 10")
      }, 2000)
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm flex-shrink-0">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Phone className="w-4 h-4 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                DealFinder AI
              </span>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">AI Agent Online</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Badge className="bg-green-100 text-green-700">Chat Interface</Badge>
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`flex items-start space-x-3 max-w-3xl ${message.type === "user" ? "flex-row-reverse space-x-reverse" : ""}`}
              >
                {/* Avatar */}
                <Avatar className="w-8 h-8 flex-shrink-0">
                  <AvatarFallback
                    className={
                      message.type === "user"
                        ? "bg-blue-100 text-blue-600"
                        : message.type === "system"
                          ? "bg-gray-100 text-gray-600"
                          : "bg-purple-100 text-purple-600"
                    }
                  >
                    {message.type === "user" ? "U" : message.type === "system" ? "S" : "AI"}
                  </AvatarFallback>
                </Avatar>

                {/* Message Content */}
                <div className={`flex flex-col ${message.type === "user" ? "items-end" : "items-start"}`}>
                  <div
                    className={`rounded-2xl px-4 py-3 max-w-full ${
                      message.type === "user"
                        ? "bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                        : message.type === "system"
                          ? "bg-gray-100 text-gray-700"
                          : "bg-white border shadow-sm"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>

                    {/* Deal Cards */}
                    {message.deals && (
                      <div className="mt-4 space-y-3">
                        {message.deals.map((deal, index) => (
                          <Card key={index} className="bg-gray-50 border-gray-200">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                                    {index + 1}
                                  </div>
                                  <div>
                                    <h4 className="font-semibold text-gray-900">{deal.seller}</h4>
                                    <div className="flex items-center gap-2 text-sm text-gray-600">
                                      <Clock className="w-3 h-3" />
                                      {deal.delivery}
                                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                      {deal.rating}
                                    </div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-xl font-bold text-green-600">${deal.price}</div>
                                  {deal.originalPrice && (
                                    <div className="text-sm text-gray-500 line-through">${deal.originalPrice}</div>
                                  )}
                                  {deal.negotiated && (
                                    <Badge className="bg-green-100 text-green-700 text-xs">Negotiated</Badge>
                                  )}
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </div>

                  <span className="text-xs text-gray-500 mt-1 px-2">{formatTime(message.timestamp)}</span>
                </div>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-3 max-w-3xl">
                <Avatar className="w-8 h-8 flex-shrink-0">
                  <AvatarFallback className="bg-purple-100 text-purple-600">AI</AvatarFallback>
                </Avatar>
                <div className="bg-white border shadow-sm rounded-2xl px-4 py-3">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.1s" }}
                    ></div>
                    <div
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                      style={{ animationDelay: "0.2s" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Searching Indicator */}
          {isSearching && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-3 max-w-3xl">
                <Avatar className="w-8 h-8 flex-shrink-0">
                  <AvatarFallback className="bg-purple-100 text-purple-600">AI</AvatarFallback>
                </Avatar>
                <div className="bg-blue-50 border border-blue-200 rounded-2xl px-4 py-3">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                    <span className="text-blue-700 font-medium">Calling resellers and negotiating prices...</span>
                  </div>
                  <div className="mt-2 text-sm text-blue-600">
                    <div className="flex items-center space-x-1 mb-1">
                      <CheckCircle className="w-3 h-3" />
                      <span>SneakerHub Pro - Connected</span>
                    </div>
                    <div className="flex items-center space-x-1 mb-1">
                      <CheckCircle className="w-3 h-3" />
                      <span>Kicks Central - Negotiating...</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>Urban Footwear - Pending...</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t bg-white/80 backdrop-blur-sm p-4 flex-shrink-0">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end space-x-3">
            <div className="flex-1 relative">
              <Input
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me to find deals on sneakers, tickets, or any exclusive drops..."
                className="pr-12 py-3 text-base resize-none min-h-[48px]"
                disabled={isRecording}
              />
              {isRecording && (
                <div className="absolute inset-0 bg-red-50 border-2 border-red-200 rounded-md flex items-center justify-center">
                  <div className="flex items-center space-x-2 text-red-600">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium">Recording...</span>
                  </div>
                </div>
              )}
            </div>

            <Button
              onClick={toggleRecording}
              variant={isRecording ? "destructive" : "outline"}
              size="lg"
              className="px-4"
            >
              {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </Button>

            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isRecording}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 px-6"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>

          <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
            <div className="flex items-center space-x-4">
              <span>Press Enter to send, Shift+Enter for new line</span>
              {isRecording && <span className="text-red-500">Voice input active</span>}
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>AI Agent Ready</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

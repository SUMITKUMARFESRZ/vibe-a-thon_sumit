"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Phone, Mail, FileSpreadsheet, Clock, DollarSign, Star, Mic, MicOff } from "lucide-react"
import Link from "next/link"

const mockResellers = [
  {
    id: 1,
    name: "SneakerHub Pro",
    price: 450,
    originalPrice: 500,
    delivery: "2-3 days",
    rating: 4.8,
    stock: "In Stock",
    negotiated: true,
  },
  {
    id: 2,
    name: "Kicks Central",
    price: 475,
    originalPrice: 475,
    delivery: "1-2 days",
    rating: 4.6,
    stock: "Limited",
    negotiated: false,
  },
  {
    id: 3,
    name: "Urban Footwear",
    price: 520,
    originalPrice: 550,
    delivery: "3-5 days",
    rating: 4.9,
    stock: "In Stock",
    negotiated: true,
  },
  {
    id: 4,
    name: "Street Style Co",
    price: 495,
    originalPrice: 495,
    delivery: "2-4 days",
    rating: 4.4,
    stock: "In Stock",
    negotiated: false,
  },
  {
    id: 5,
    name: "Elite Sneakers",
    price: 465,
    originalPrice: 480,
    delivery: "1-3 days",
    rating: 4.7,
    stock: "In Stock",
    negotiated: true,
  },
]

export default function Dashboard() {
  const [isSearching, setIsSearching] = useState(false)
  const [searchProgress, setSearchProgress] = useState(0)
  const [showResults, setShowResults] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const startVoiceSearch = () => {
    setIsSearching(true)
    setSearchProgress(0)
    setShowResults(false)

    // Simulate search progress
    const interval = setInterval(() => {
      setSearchProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsSearching(false)
          setShowResults(true)
          return 100
        }
        return prev + 10
      })
    }, 500)
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
  }

  const topThreeDeals = mockResellers.sort((a, b) => a.price - b.price).slice(0, 3)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Phone className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              DealFinder AI
            </span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/chat" className="text-gray-600 hover:text-purple-600 transition-colors">
              Chat
            </Link>
            <Link href="/dashboard" className="text-gray-600 hover:text-purple-600 transition-colors">
              Dashboard
            </Link>
          </nav>
          <Badge className="bg-green-100 text-green-700">Dashboard</Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Search Panel */}
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mic className="w-5 h-5" />
                  Voice Search
                </CardTitle>
                <CardDescription>Tell our AI what you're looking for and let it find the best deals</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="product">Product Category</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sneakers">Limited Edition Sneakers</SelectItem>
                      <SelectItem value="concert">Concert Tickets</SelectItem>
                      <SelectItem value="sports">Sports Event Tickets</SelectItem>
                      <SelectItem value="fashion">Fashion Drops</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="query">Search Query</Label>
                  <Textarea
                    id="query"
                    placeholder="e.g., Jordan 4 Black Cat size 10, Taylor Swift Eras Tour tickets, IPL Final tickets..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                <div>
                  <Label htmlFor="budget">Max Budget ($)</Label>
                  <Input id="budget" type="number" placeholder="500" />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={toggleRecording}
                    variant={isRecording ? "destructive" : "outline"}
                    className="flex-1"
                  >
                    {isRecording ? <MicOff className="w-4 h-4 mr-2" /> : <Mic className="w-4 h-4 mr-2" />}
                    {isRecording ? "Stop Recording" : "Voice Input"}
                  </Button>
                </div>

                <Button
                  onClick={startVoiceSearch}
                  disabled={isSearching}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {isSearching ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Searching...
                    </>
                  ) : (
                    <>
                      <Phone className="w-4 h-4 mr-2" />
                      Start AI Search
                    </>
                  )}
                </Button>

                {isSearching && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Calling resellers...</span>
                      <span>{searchProgress}%</span>
                    </div>
                    <Progress value={searchProgress} className="w-full" />
                    <div className="text-xs text-gray-500">
                      {searchProgress < 30 && "Contacting SneakerHub Pro..."}
                      {searchProgress >= 30 && searchProgress < 60 && "Negotiating with Kicks Central..."}
                      {searchProgress >= 60 && searchProgress < 90 && "Comparing Urban Footwear offers..."}
                      {searchProgress >= 90 && "Finalizing best deals..."}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2">
            {!showResults && !isSearching && (
              <Card className="h-96 flex items-center justify-center">
                <CardContent className="text-center">
                  <Phone className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">Ready to Find Deals</h3>
                  <p className="text-gray-500">Start a voice search to see real-time results from multiple resellers</p>
                </CardContent>
              </Card>
            )}

            {showResults && (
              <div className="space-y-6">
                {/* Top 3 Recommendations */}
                <Card className="border-green-200 bg-green-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-800">
                      <Star className="w-5 h-5" />
                      Top 3 Recommendations
                    </CardTitle>
                    <CardDescription className="text-green-700">
                      Best deals found based on price, delivery, and seller rating
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4">
                      {topThreeDeals.map((deal, index) => (
                        <div key={deal.id} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                          <div className="flex items-center gap-4">
                            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <h4 className="font-semibold">{deal.name}</h4>
                              <div className="flex items-center gap-2 text-sm text-gray-600">
                                <Clock className="w-3 h-3" />
                                {deal.delivery}
                                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                {deal.rating}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-green-600">${deal.price}</div>
                            {deal.negotiated && (
                              <div className="text-sm text-gray-500 line-through">${deal.originalPrice}</div>
                            )}
                            <Badge variant={deal.stock === "In Stock" ? "default" : "secondary"} className="text-xs">
                              {deal.stock}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* All Results */}
                <Card>
                  <CardHeader>
                    <CardTitle>All Reseller Offers</CardTitle>
                    <CardDescription>Complete comparison of all available deals</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4">
                      {mockResellers.map((reseller) => (
                        <div
                          key={reseller.id}
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                              <DollarSign className="w-6 h-6 text-gray-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold">{reseller.name}</h4>
                              <div className="flex items-center gap-4 text-sm text-gray-600">
                                <div className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {reseller.delivery}
                                </div>
                                <div className="flex items-center gap-1">
                                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                  {reseller.rating}
                                </div>
                                <Badge
                                  variant={reseller.stock === "In Stock" ? "default" : "secondary"}
                                  className="text-xs"
                                >
                                  {reseller.stock}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-xl font-bold">${reseller.price}</div>
                            {reseller.negotiated && (
                              <div className="text-sm text-gray-500 line-through">${reseller.originalPrice}</div>
                            )}
                            {reseller.negotiated && (
                              <Badge className="bg-green-100 text-green-700 text-xs">Negotiated</Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex gap-4">
                  <Button className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    <Mail className="w-4 h-4 mr-2" />
                    Send Email Report
                  </Button>
                  <Button variant="outline" className="flex-1">
                    <FileSpreadsheet className="w-4 h-4 mr-2" />
                    Export to Sheets
                  </Button>
                  <Link href="/chat" className="flex-1">
                    <Button variant="outline" className="w-full">
                      <Phone className="w-4 h-4 mr-2" />
                      Chat with AI
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DealFinder AI - Voice Agent for High-Demand Drops",
  description:
    "AI-powered voice agent that finds the best deals on limited-edition sneakers, concert tickets, and exclusive drops by calling multiple resellers and negotiating prices.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
